﻿namespace OthelloLogic
{
    public interface IBoard
    {
        public Guid BoardId { get; }
    }
}
