﻿namespace OthelloLogic
{
    public interface IPlayer
    {
        Guid PlayerId { get; }
        string PlayerName { get; }
    }
}
