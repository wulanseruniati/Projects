﻿namespace OthelloLogic
{
    public enum GameOverOption
    {
        Restart,
        Exit
    }
}
