﻿namespace OthelloLogic
{
    public enum GameState
    {
        INIT, GAME_END
    }
}
